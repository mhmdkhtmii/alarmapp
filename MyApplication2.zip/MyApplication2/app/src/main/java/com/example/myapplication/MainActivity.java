package com.example.myapplication;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements AlarmAdapter.OnAlarmDeleteListener, AlarmAdapter.OnAlarmStopListener {

    private static final int REQUEST_CODE_SELECT_SONG = 1;
    private static final int REQUEST_PERMISSION_READ_STORAGE = 100;

    private TimePicker timePicker;
    private Button btnSelectSong, btnSetAlarm;
    private RecyclerView recyclerView;
    private AlarmAdapter alarmAdapter;
    private List<AlarmItem> alarmList = new ArrayList<>();

    private String selectedSongPath = "";
    private String selectedSongName = "";

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "AlarmPrefs";

    private static final int REQUEST_CODE_PICK_VIDEO = 200;
    private Uri selectedVideoUri;
    private String selectedVideoPath = "";
    private String selectedVideoName = "";

    private CheckBox[] dayCheckBoxes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ویوها
        timePicker = findViewById(R.id.timePicker);
        btnSelectSong = findViewById(R.id.btnSelectSong);
        btnSetAlarm = findViewById(R.id.btnSetAlarm);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        alarmAdapter = new AlarmAdapter(alarmList, this, this);
        recyclerView.setAdapter(alarmAdapter);

        dayCheckBoxes = new CheckBox[] {
                findViewById(R.id.chkSun),
                findViewById(R.id.chkMon),
                findViewById(R.id.chkTue),
                findViewById(R.id.chkWed),
                findViewById(R.id.chkThu),
                findViewById(R.id.chkFri),
                findViewById(R.id.chkSat)
        };



        btnSelectSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_READ_STORAGE);
                    return;
                }

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("audio/*");
                startActivityForResult(intent, REQUEST_CODE_SELECT_SONG);
            }
        });

        btnSetAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int hour, minute;

                if (Build.VERSION.SDK_INT >= 23) {
                    hour = timePicker.getHour();
                    minute = timePicker.getMinute();
                } else {
                    hour = timePicker.getCurrentHour();
                    minute = timePicker.getCurrentMinute();
                }

                // حالا چک می‌کنیم حداقل آهنگ یا ویدیو انتخاب شده باشد
                if (selectedSongPath.isEmpty() && selectedVideoPath.isEmpty()) {
                    Toast.makeText(MainActivity.this, "لطفا یک آهنگ یا ویدیو انتخاب کنید.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int alarmId = (int) System.currentTimeMillis();

                // repeatDays همه false چون چک باکس حذف شد
                boolean[] repeatDays = new boolean[7];
                for (int i = 0; i < 7; i++) {
                    repeatDays[i] = dayCheckBoxes[i].isChecked();
                }


                // اگر ویدیو انتخاب شده، آلارم با ویدیو تنظیم شود، در غیر این صورت با آهنگ
                String pathToUse = !selectedVideoPath.isEmpty() ? selectedVideoPath : selectedSongPath;
                String nameToUse = !selectedVideoPath.isEmpty() ? selectedVideoName : selectedSongName;

                AlarmItem alarmItem = new AlarmItem(alarmId, hour, minute, pathToUse, nameToUse, repeatDays);
                alarmList.add(alarmItem);
                alarmAdapter.notifyDataSetChanged();

                saveAlarms();

                scheduleAlarm(alarmItem);

                Toast.makeText(MainActivity.this, "آلارم تنظیم شد.", Toast.LENGTH_SHORT).show();
            }
        });

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        loadAlarms();

        Button btnSelectVideo = findViewById(R.id.btnSelectVideo);
        btnSelectVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("video/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, REQUEST_CODE_PICK_VIDEO);
            }
        });
    }

    private void scheduleAlarm(AlarmItem alarmItem) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        for (int day = 0; day < 7; day++) {
            if (alarmItem.repeatDays[day]) {
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, alarmItem.hour);
                calendar.set(Calendar.MINUTE, alarmItem.minute);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                calendar.set(Calendar.DAY_OF_WEEK, day + 1); // Calendar.SUNDAY = 1

                if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                    calendar.add(Calendar.WEEK_OF_YEAR, 1);
                }

                Intent intent = new Intent(this, AlarmReceiver.class);
                intent.putExtra("alarmId", alarmItem.id);
                if (alarmItem.songPath.endsWith(".mp4") || alarmItem.songPath.endsWith(".mkv") || alarmItem.songPath.endsWith(".avi")) {
                    intent.putExtra("videoPath", alarmItem.songPath);
                } else {
                    intent.putExtra("songPath", alarmItem.songPath);
                }

                PendingIntent pendingIntent = PendingIntent.getBroadcast(this,
                        alarmItem.id * 10 + day,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);


                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                }

            }
        }

        // اگر هیچ روزی انتخاب نشده بود، فقط یکبار در نزدیک‌ترین زمان تنظیم شود
        boolean noRepeat = true;
        for (boolean b : alarmItem.repeatDays) {
            if (b) {
                noRepeat = false;
                break;
            }
        }

        if (noRepeat) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, alarmItem.hour);
            calendar.set(Calendar.MINUTE, alarmItem.minute);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                calendar.add(Calendar.DAY_OF_YEAR, 1);
            }

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("alarmId", alarmItem.id);
            if (alarmItem.songPath.endsWith(".mp4") || alarmItem.songPath.endsWith(".mkv") || alarmItem.songPath.endsWith(".avi")) {
                intent.putExtra("videoPath", alarmItem.songPath);
            } else {
                intent.putExtra("songPath", alarmItem.songPath);
            }

            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, alarmItem.id, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        }
    }


    private void cancelAlarm(AlarmItem alarmItem) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        for (int day = 0; day < 7; day++) {
            int requestCode = alarmItem.repeatDays[day] ? alarmItem.id * 10 + day : alarmItem.id;
            Intent intent = new Intent(this, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            if (alarmManager != null) {
                alarmManager.cancel(pendingIntent);
            }
        }
    }


    private void saveAlarms() {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Set<String> alarmSet = new HashSet<>();
        for (AlarmItem alarm : alarmList) {
            StringBuilder daysStr = new StringBuilder();
            for (boolean b : alarm.repeatDays) {
                daysStr.append(b ? "1" : "0");
            }
            String alarmString = alarm.id + "," + alarm.hour + "," + alarm.minute + "," +
                    alarm.songPath.replace(",", "%2C") + "," + alarm.songName.replace(",", "%2C") + "," + daysStr.toString();
            alarmSet.add(alarmString);
        }
        editor.putStringSet("alarms", alarmSet);
        editor.apply();
    }

    private void loadAlarms() {
        Set<String> alarmSet = sharedPreferences.getStringSet("alarms", null);
        if (alarmSet != null) {
            alarmList.clear();
            for (String alarmString : alarmSet) {
                try {
                    String[] parts = alarmString.split(",");
                    if (parts.length >= 6) {
                        int id = Integer.parseInt(parts[0]);
                        int hour = Integer.parseInt(parts[1]);
                        int minute = Integer.parseInt(parts[2]);
                        String songPath = parts[3].replace("%2C", ",");
                        String songName = parts[4].replace("%2C", ",");

                        String daysStr = parts[5];
                        if (daysStr.length() < 7) {
                            daysStr = "0000000";
                        }

                        boolean[] repeatDays = new boolean[7];
                        for (int i = 0; i < 7; i++) {
                            repeatDays[i] = daysStr.charAt(i) == '1';
                        }

                        AlarmItem alarmItem = new AlarmItem(id, hour, minute, songPath, songName, repeatDays);
                        alarmList.add(alarmItem);
                        scheduleAlarm(alarmItem);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            alarmAdapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onAlarmDelete(AlarmItem alarmItem) {
        cancelAlarm(alarmItem);
        alarmList.remove(alarmItem);
        alarmAdapter.notifyDataSetChanged();
        saveAlarms();
        Toast.makeText(this, "آلارم حذف شد.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAlarmStop() {
        if (AlarmReceiver.mediaPlayer != null && AlarmReceiver.mediaPlayer.isPlaying()) {
            AlarmReceiver.mediaPlayer.stop();
            AlarmReceiver.mediaPlayer.release();
            AlarmReceiver.mediaPlayer = null;
            Toast.makeText(this, "آلارم متوقف شد.", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();

            if (uri != null) {
                // گرفتن دسترسی دائمی به Uri
                final int takeFlags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(uri, takeFlags);
            }

            if (requestCode == REQUEST_CODE_SELECT_SONG && uri != null) {
                selectedSongPath = uri.toString();

                // استخراج اسم فایل از Uri
                String path = uri.getPath();
                if (path != null) {
                    int lastSlash = path.lastIndexOf('/');
                    if (lastSlash >= 0 && lastSlash < path.length() - 1) {
                        selectedSongName = path.substring(lastSlash + 1);
                    } else {
                        selectedSongName = path;
                    }
                } else {
                    selectedSongName = "آهنگ انتخاب شده";
                }

                btnSelectSong.setText("🎵 " + selectedSongName);

                // پاک کردن مسیر ویدیو چون الان آهنگ انتخاب شده
                selectedVideoPath = "";
                selectedVideoName = "";

            } else if (requestCode == REQUEST_CODE_PICK_VIDEO && uri != null) {
                selectedVideoUri = uri;
                selectedVideoPath = selectedVideoUri.toString();

                // استخراج اسم فایل از Uri
                String path = uri.getPath();
                if (path != null) {
                    int lastSlash = path.lastIndexOf('/');
                    if (lastSlash >= 0 && lastSlash < path.length() - 1) {
                        selectedVideoName = path.substring(lastSlash + 1);
                    } else {
                        selectedVideoName = path;
                    }
                } else {
                    selectedVideoName = "ویدیو انتخاب شده";
                }

                // دکمه آهنگ را به حالت اولیه برمی‌گردانیم چون ویدیو انتخاب شده است
                btnSelectSong.setText("انتخاب آهنگ");

                Toast.makeText(this, "ویدیو انتخاب شد: " + selectedVideoName, Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PERMISSION_READ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                btnSelectSong.performClick();
            } else {
                Toast.makeText(this, "دسترسی به حافظه داده نشده است.", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
