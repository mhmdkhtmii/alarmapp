package com.example.myapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AlarmActivity extends AppCompatActivity {

    private final List<MediaPlayer> audioPlayers = new ArrayList<>();
    private final List<VideoView> videoViews = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // روشن نگه داشتن صفحه
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // لایه اصلی برای نمایش چند ویدیو
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        setContentView(rootLayout);

        Intent intent = getIntent();
        ArrayList<String> videoPaths = intent.getStringArrayListExtra("videoPaths");
        ArrayList<String> songPaths = intent.getStringArrayListExtra("songPaths");

        boolean hasContent = false;

        // پخش ویدیوها
        if (videoPaths != null && !videoPaths.isEmpty()) {
            hasContent = true;
            for (String path : videoPaths) {
                VideoView videoView = new VideoView(this);
                videoView.setVideoURI(Uri.parse(path));
                videoView.setZOrderOnTop(true);
                videoView.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    videoView.start();
                });
                videoView.setOnErrorListener((mp, what, extra) -> {
                    Toast.makeText(this, "خطا در پخش ویدیو", Toast.LENGTH_SHORT).show();
                    return true;
                });

                videoViews.add(videoView);
                rootLayout.addView(videoView,
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                500)); // ارتفاع برای هر ویدیو
            }
        }

        // پخش آهنگ‌ها
        if (songPaths != null && !songPaths.isEmpty()) {
            hasContent = true;
            for (String path : songPaths) {
                try {
                    MediaPlayer player = new MediaPlayer();
                    player.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    player.setDataSource(this, Uri.parse(path));
                    player.setLooping(true);
                    player.prepare();
                    player.start();
                    audioPlayers.add(player);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "خطا در پخش آهنگ", Toast.LENGTH_SHORT).show();
                }
            }
        }

        if (!hasContent) {
            Toast.makeText(this, "هیچ فایل معتبری برای پخش وجود ندارد!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        for (VideoView vv : videoViews) {
            if (vv.isPlaying()) vv.pause();
        }
        for (MediaPlayer mp : audioPlayers) {
            if (mp.isPlaying()) mp.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (VideoView vv : videoViews) {
            if (!vv.isPlaying()) vv.start();
        }
        for (MediaPlayer mp : audioPlayers) {
            if (!mp.isPlaying()) mp.start();
        }
    }

    @Override
    protected void onDestroy() {
        for (VideoView vv : videoViews) {
            vv.stopPlayback();
        }
        for (MediaPlayer mp : audioPlayers) {
            if (mp != null) {
                if (mp.isPlaying()) mp.stop();
                mp.release();
            }
        }
        videoViews.clear();
        audioPlayers.clear();
        super.onDestroy();
    }
}
