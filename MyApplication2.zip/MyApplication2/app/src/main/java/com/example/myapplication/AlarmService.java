package com.example.myapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class AlarmService extends Service {

    private MediaPlayer mediaPlayer;
    private static final String CHANNEL_ID = "AlarmChannel";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String songPath = intent.getStringExtra("songPath");

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("آلارم در حال پخش است")
                .setContentText("برای توقف، برنامه را باز کنید.")
                .setSmallIcon(R.mipmap.ic_launcher) // آیکون درست جایگزین شود
                .build();

        startForeground(1, notification);

        if (songPath != null) {
            try {
                mediaPlayer = new MediaPlayer();

                if (songPath.startsWith("content://")) {
                    Uri uri = Uri.parse(songPath);
                    mediaPlayer.setDataSource(this, uri);
                } else {
                    mediaPlayer.setDataSource(songPath);
                }

                mediaPlayer.setOnPreparedListener(mp -> mediaPlayer.start());
                mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                    Log.e("AlarmService", "MediaPlayer Error: what=" + what + ", extra=" + extra);
                    stopSelf();
                    return true;
                });

                mediaPlayer.prepareAsync();

            } catch (Exception e) {
                Log.e("AlarmService", "خطا در پخش آلارم", e);
                stopSelf();
            }
        } else {
            Log.e("AlarmService", "songPath دریافت نشد");
            stopSelf();
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Alarm Notification Channel",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
}
