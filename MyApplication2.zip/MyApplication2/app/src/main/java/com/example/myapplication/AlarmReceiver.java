package com.example.myapplication;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;


public class AlarmReceiver extends BroadcastReceiver {

    public static MediaPlayer mediaPlayer;

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("STOP_ALARM".equals(intent.getAction())) {
            stopAlarm(context);
            return;
        }

        String songPath = intent.getStringExtra("songPath");
        String videoPath = intent.getStringExtra("videoPath");

        stopAlarm(context); // توقف پخش قبلی

        if (videoPath != null && !videoPath.isEmpty()) {
            // اگر ویدیو وجود دارد -> باز کردن AlarmActivity
            Intent videoIntent = new Intent(context, AlarmActivity.class);
            videoIntent.putExtra("videoPath", videoPath);
            videoIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(videoIntent);

            Toast.makeText(context, "آلارم ویدیویی شروع شد!", Toast.LENGTH_SHORT).show();
            showAlarmNotification(context);

            return;
        }

        if (songPath != null && !songPath.isEmpty()) {
            try {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, Uri.parse(songPath));
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                mediaPlayer.start();

                Toast.makeText(context, "آلارم صوتی شروع شد!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(context, "خطا در پخش آلارم صوتی", Toast.LENGTH_SHORT).show();
            }
            showAlarmNotification(context);

            return;
        }

        Toast.makeText(context, "مسیر ویدیو یا آهنگ نامعتبر است!", Toast.LENGTH_SHORT).show();
    }

    public static void stopAlarm(Context context) {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                // حذف نوتیفیکیشن
                NotificationManager manager = (NotificationManager)
                        context.getSystemService(Context.NOTIFICATION_SERVICE);
                manager.cancel(1001);

            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
    private void showAlarmNotification(Context context) {
        String channelId = "alarm_channel_id";
        String channelName = "Alarm Channel";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        // Intent برای توقف آلارم
        Intent stopIntent = new Intent(context, AlarmReceiver.class);
        stopIntent.setAction("STOP_ALARM");

        PendingIntent stopPendingIntent = PendingIntent.getBroadcast(
                context, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
// Intent برای باز کردن برنامه (مثلاً MainActivity)
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent contentPendingIntent = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("آلارم فعال است")
                .setContentText("برای توقف، روی دکمه کلیک کنید")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(contentPendingIntent)
                .addAction(android.R.drawable.ic_media_pause, "توقف آلارم", stopPendingIntent)
                .setOngoing(true);

        NotificationManager manager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(1001, builder.build());
    }

}
