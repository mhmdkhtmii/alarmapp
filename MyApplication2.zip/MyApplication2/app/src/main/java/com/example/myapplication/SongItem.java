package com.example.myapplication;

public class SongItem {
    public String name;
    public String uri;

    public SongItem(String name, String uri) {
        this.name = name;
        this.uri = uri;
    }

    @Override
    public String toString() {
        return name;
    }
}