package com.example.myapplication;

public class ScheduledSong {
    public String time;
    public String songUri;

    public ScheduledSong(String time, String songUri) {
        this.time = time;
        this.songUri = songUri;
    }

    @Override
    public String toString() {
        return "⏰ " + time + "\n🎵 " + songUri;
    }
}