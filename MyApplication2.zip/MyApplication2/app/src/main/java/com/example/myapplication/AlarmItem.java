package com.example.myapplication;

import java.util.Locale;

public class AlarmItem {
    public int id;
    public int hour, minute;
    public String songPath, songName;
    // 6 روز: شنبه تا جمعه
    public boolean[] repeatDays; // length=6, index 0=شنبه ... 5=جمعه

    public AlarmItem(int id, int hour, int minute, String songPath, String songName, boolean[] repeatDays) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.songPath = songPath;
        this.songName = songName;
        this.repeatDays = repeatDays;
    }

    public String getTimeString() {
        return String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
    }

    public String getSongPath() {
        return songPath;
    }

    public boolean isRepeatOn(int dayIndex) {
        if (repeatDays == null || repeatDays.length < 7) return false;
        return repeatDays[dayIndex];
    }

    // متد جدید برای نمایش روزهای تکرار به صورت متن کوتاه فارسی
    public String getRepeatDaysString() {
        if (repeatDays == null || repeatDays.length < 7) return "فقط یک‌بار";

        String[] days = {"یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنج شنبه", "جمعه", "شنبه"};  // شنبه تا جمعه
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < 7; i++) {
            if (repeatDays[i]) {
                if (builder.length() > 0) builder.append(", ");
                builder.append(days[i]);
            }
        }

        return builder.length() > 0 ? builder.toString() : "فقط یک‌بار";
    }

}