package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder> {

    public interface OnAlarmDeleteListener {
        void onAlarmDelete(AlarmItem alarmItem);
    }

    public interface OnAlarmStopListener {
        void onAlarmStop();
    }

    private List<AlarmItem> alarmList;
    private OnAlarmDeleteListener deleteListener;
    private OnAlarmStopListener stopListener;

    public AlarmAdapter(List<AlarmItem> alarmList, OnAlarmDeleteListener deleteListener, OnAlarmStopListener stopListener) {
        this.alarmList = alarmList;
        this.deleteListener = deleteListener;
        this.stopListener = stopListener;
    }

    @Override
    public AlarmViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_alarm, parent, false);
        return new AlarmViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AlarmViewHolder holder, int position) {
        final AlarmItem alarmItem = alarmList.get(position);
        String displayText = alarmItem.getTimeString() + " - " + alarmItem.songName + " (" + alarmItem.getRepeatDaysString() + ")";
        holder.tvTime.setText(displayText);

        holder.btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stopListener != null) {
                    stopListener.onAlarmStop();
                }
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onAlarmDelete(alarmItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return alarmList.size();
    }

    static class AlarmViewHolder extends RecyclerView.ViewHolder {
        TextView tvTime;
        Button btnStop, btnDelete;

        public AlarmViewHolder(View itemView) {
            super(itemView);
            tvTime = (TextView) itemView.findViewById(R.id.tvTime);
            btnStop = (Button) itemView.findViewById(R.id.btnStop);
            btnDelete = (Button) itemView.findViewById(R.id.btnDelete);
        }
    }
}